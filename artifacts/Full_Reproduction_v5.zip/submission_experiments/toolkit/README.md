# OSIRIS runtime

This is the submission runtime subset. See ../RUNNING.md for model execution and ../README.md for data analysis.
