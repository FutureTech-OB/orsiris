"""Verify all shipped files against SHA-256, independent of working directory."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
files=json.loads((root/'manifest.json').read_text(encoding='utf-8'))['files']
for r in files:
    p=(root/r['path']).resolve()
    if not p.is_relative_to(root) or not p.is_file():raise RuntimeError('Missing/unsafe file: '+r['path'])
    if hashlib.sha256(p.read_bytes()).hexdigest()!=r['sha256']:raise RuntimeError('Hash mismatch: '+r['path'])
print(json.dumps({'passed':True,'verified_files':len(files)}))
