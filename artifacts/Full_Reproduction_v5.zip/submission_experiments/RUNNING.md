# Rerunning the model experiments

Prepare local Qwen3.5-9B/27B models and the corresponding SAE/J-Lens weights in a Linux CUDA environment. Install a CUDA-compatible PyTorch build first. Large model and dictionary weights are not distributed. Small frozen directions and controllers are included in the experiment modules' `assets/` directories. Recalibration may produce different configurations and scores; stored-data recomputation reproduces the sealed results.

## Decision-time readout

After installing the toolkit dependencies shown below, run from the package root:

```bash
python readout/run_readout.py --protocol readout/protocol.json --model /models/Qwen3.5-9B --size 9b --directions readout/assets/9b/directions.pt --output new_readout/9b
python readout/run_readout.py --protocol readout/protocol.json --model /models/Qwen3.5-27B --size 27b --directions readout/assets/27b/directions.pt --output new_readout/27b
python readout/analyze.py --data new_readout --protocol readout/protocol.json --output new_readout_results
```

These commands reuse the model-specific directions and record the decision position at the three designated layers. They do not explore additional positions or paraphrases. The packaged runner was extracted from the original implementation; packaging validation covers data and execution preparation, not a new GPU forward pass.

## Social-choice pilot experiments

From the package root:

```bash
python -m pip install -e './toolkit[hf]'
python toolkit/cookbook/social_choices/launch.py --protocol social_choices/configs/9b.json --model /models/Qwen3.5-9B --directions social_choices/assets/9b/directions.pt --output new_runs/9b --study-gpus 0:1
python toolkit/cookbook/social_choices/launch.py --protocol social_choices/configs/27b.json --model /models/Qwen3.5-27B --directions social_choices/assets/27b/directions.pt --output new_runs/27b --study-gpus 0:1
python social_choices/data_processing/analyze.py --configs social_choices/configs --data new_runs --output new_social_results
```

Run sequentially or assign non-overlapping GPUs. The original 27B batch size of 64 requires sufficient GPU memory. To extract directions again, use `toolkit/cookbook/social_choices/extract.py`; see its `--help` output.

## Managerial experiments

Enter `managerial/` and install `environment/requirements.txt`. The following commands preserve the original calibration design; candidate selection is part of source calibration.

```bash
python code/run.py plan
python code/run.py calibrate --study HRM_1_1 --model /models/Qwen3.5-27B --sae-root /models/SAE27B --gpus 0,1 --output new_runs/pay
python code/run.py calibrate --study AMJ_1_3 --model /models/Qwen3.5-27B --sae-root /models/SAE27B --gpus 0,1 --output new_runs/voice
python code/run.py calibrate --study JAP_4_2b --model /models/Qwen3.5-27B --sae-root /models/SAE27B --gpus 0,1 --output new_runs/ceo
python code/run.py transfer --model /models/Qwen3.5-27B --sae-root /models/SAE27B --gpus 0,1 --controller-dir new_runs/ceo/results/JAP_4_2b --output new_runs/trust
python code/collect.py --bundle . --pay-run new_runs/pay --voice-run new_runs/voice --ceo-run new_runs/ceo --trust-run new_runs/trust --output new_readouts
python data_processing/analyze.py --data new_readouts/data --references new_readouts/references --output new_results
```

The SAE directory must contain `layer48.sae.pt`. To rerun transfer using the historical frozen controller only, omit `--controller-dir`. To evaluate a newly calibrated source-to-transfer chain, supply the newly frozen controller directory as shown above. `--prepare-only` writes execution plans without loading the model. All source and transfer shards must complete before collection; the analyzer verifies record coverage.
