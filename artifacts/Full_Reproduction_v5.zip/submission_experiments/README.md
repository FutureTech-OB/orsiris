# Submission experiments v5

This package contains only the experiments selected for the submission. Unused exploratory experiments, previous reports, draft manuscripts, and debugging outputs are excluded.

## Contents

| Directory | Experiments | Records |
| --- | --- | --- |
| social_choices | Qwen3.5-9B and 27B: fair/unfair in the ultimatum game; calm/anger in the credit-taking scenario | 60,000 generated responses; six condition cells per model, with 5,000 responses per cell |
| managerial | Director compensation, employee voice, CEO trust source calibration, and restaurant-manager trust transfer | 606 option-probability records: 101 condition-by-item inputs, three option orders, and two methods |
| readout | Decision-time J-Lens readout in two models and two scenarios | Four forward-pass records; 32 emotion/feeling candidates and six appraisal candidates per record |
| results | Results recomputed from the stored records | Twenty managerial effect contrasts across four tasks, including money/time trust summaries |

## Recompute without a GPU

Python 3.10 or later is required; analysis uses only the standard library. From the extracted `submission_experiments` directory, run:

```bash
python verify.py
python recompute.py --output recomputed
```

`verify.py` checks the release files against their SHA-256 manifest. `recompute.py` reconstructs results from individual stored records and checks them against the sealed expected values. It writes to a new directory. `expected_results.json` supplies verification targets, not inputs to the effect calculations.

## Analysis conventions

Managerial analyses calculate expected item scores from option probabilities, then reconstruct treatment effects using the human studies' group contrasts and scoring rules. Effect error is the absolute difference between model and human treatment effects. Scale-normalized error divides that distance by the response-scale span.

Compensation and voice calculate absolute errors within option orderings before averaging. CEO and restaurant trust average effects across orderings before calculating absolute errors; per-order sensitivity is also reported. These tasks are not combined into a single improvement rate.

| Task | Relative error reduction under the reported metric | Use |
| --- | ---: | --- |
| Director compensation | 61.68% | Source calibration |
| Employee voice | 45.50% | Source calibration |
| CEO trust | 47.42% | Source calibration; pooled-order evaluation matching the transfer metric |
| Restaurant-manager trust | 24.31% | Transfer of the frozen CEO controller |

CEO trust has a -1.34% reduction under per-order evaluation, distinct from its 47.42% pooled-order reduction; both are retained. Its nine contrasts are linearly dependent. In the restaurant task, all three money-condition errors decrease. In the time condition, ability and benevolence errors increase and integrity error decreases; mean time-condition error decreases by 16.93%.

The social-choice configurations retain the final doses: 9B anger uses 11.30625, three-quarters of the original dose; 27B anger uses 15.075; calm uses 15.075 in both models. Ultimatum projection coefficients are 1. Generation counts quantify a fixed scenario's sampling distribution, not the number of independent scenarios or human participants.

## Two archives

- Data_Recompute_v5.zip: stored data, analysis scripts, configurations, results, and integrity verification.
- Full_Reproduction_v5.zip: the same materials plus model-execution code, frozen directions/controllers, protocols, and environment records. See `RUNNING.md` in that archive.

The v5 English release changes documentation, source comments/docstrings, and diagnostic messages. Original experimental records, prompts, protocol labels, frozen assets, and result values remain byte-for-byte unchanged. Some original data/protocol labels therefore remain in Chinese; these are preserved experimental artifacts, not untranslated code comments. Manifests are regenerated for this release. The original sealed archives remain unchanged.

The proposal working document and revision notes are supplied separately. No new GPU behavioral experiment is run during this packaging step. Base models and large SAE/J-Lens weights must be obtained separately.
