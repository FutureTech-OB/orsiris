"""CPU-only recomputation of the selected submission experiments."""
from pathlib import Path
import argparse,json,math,statistics,subprocess,sys
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--output',default='recomputed');a=p.parse_args()
out=Path(a.output).resolve();out.mkdir(parents=True,exist_ok=True)
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def close(a,b):
    if isinstance(b,dict):
        for k,v in b.items():close(a[k],v)
    elif isinstance(b,list):
        assert len(a)==len(b)
        for x,y in zip(a,b):close(x,y)
    elif isinstance(b,(int,float)) and not isinstance(b,bool):assert math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-10),(a,b)
    else:assert a==b,(a,b)
for module,extra in [('social_choices',['--configs',str(ROOT/'social_choices/configs')]),('managerial',['--references',str(ROOT/'managerial/references')])]:
    cmd=[sys.executable,'-X','utf8',str(ROOT/module/'data_processing/analyze.py'),'--data',str(ROOT/module/'data'),'--output',str(out/module),*extra]
    result=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8')
    (out/(module+'.log')).write_text(result.stdout+result.stderr,encoding='utf-8')
    if result.returncode:raise RuntimeError(result.stderr or result.stdout)
expected=load(ROOT/'expected_results.json')
subprocess.run([sys.executable,'-X','utf8',str(ROOT/'readout/analyze.py'),'--data',str(ROOT/'readout/data'),'--protocol',str(ROOT/'readout/protocol.json'),'--output',str(out/'readout')],check=True,capture_output=True)
close(load(out/'readout/summary.json')['scenarios'],expected['readout'])
social=load(out/'social_choices/summary.json');manager=load(out/'managerial/summary.json')
close(social['models'],expected['social_models'])
for s in manager['studies']:
    for m in ['prompt','sae']:close(s['methods'][m]['raw_effect_mae'],expected['managerial'][s['study_id']][m])
effects=load(out/'managerial/effects.json')
def aggregate(sid,term=None):
    groups={m:[r for r in effects if r['study_id']==sid and r['method']==m and (term is None or term in r['effect_id'])] for m in ['prompt','sae']}
    b=statistics.mean(r['raw_error'] for r in groups['prompt']);s=statistics.mean(r['raw_error'] for r in groups['sae'])
    bo=statistics.mean(r['per_order_raw_error'] for r in groups['prompt']);so=statistics.mean(r['per_order_raw_error'] for r in groups['sae'])
    return dict(effects=len(groups['prompt']),prompt_raw_mae=b,sae_raw_mae=s,reduction=1-s/b,improved_effects=sum(y['raw_error']<x['raw_error'] for x,y in zip(groups['prompt'],groups['sae'])),prompt_per_order_mae=bo,sae_per_order_mae=so,per_order_reduction=1-so/bo)
trust={'ceo_source':aggregate('JAP_4_2b'),'restaurant_all':aggregate('JAP_4_1_new'),'restaurant_money':aggregate('JAP_4_1_new','_money_'),'restaurant_time':aggregate('JAP_4_1_new','_time_')}
close(trust,expected['trust_breakdown'])
(out/'trust_breakdown.json').write_text(json.dumps(trust,ensure_ascii=False,indent=2),encoding='utf-8')
counts={m:sum(1 for p in (ROOT/m/'data').rglob('*.jsonl') for line in p.open(encoding='utf-8') if line.strip()) for m in ['social_choices','managerial']}
assert counts=={'social_choices':60000,'managerial':606},counts
report={'passed':True,'records':counts,'decision_readout_records':4,'managerial_studies':4,'effect_contrasts':20,'scope':'Saved-data recomputation; no new human observations or model calls.'}
(out/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
